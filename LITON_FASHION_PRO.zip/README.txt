LITON FASHION PRO — আপডেটেড রেসপনসিভ ওয়েবসাইট

1) ZIP Extract করুন।
2) ভেতরের index.html ফাইলটি GitHub Repository-র root-এ আপলোড করুন এবং পুরনো index.html replace করুন।
3) index.html সম্পাদনা করে WHATSAPP_NUMBER = "8801XXXXXXXXX" লাইনে নিজের WhatsApp নম্বর বসান। নম্বরের আগে + দেবেন না, স্পেসও নয়।
4) products ডেটায় পণ্যের নাম/দাম বদলাতে পারবেন।
5) GitHub Settings > Pages-এ main branch এবং /(root) নির্বাচন করা থাকতে হবে।

গুরুত্বপূর্ণ: পোশাকের emoji শুধু placeholder; বাস্তব পণ্যের ছবি বসালে আরও ভালো দেখাবে। এটি স্ট্যাটিক সাইট—অর্ডার WhatsApp-এ যায়, অনলাইন পেমেন্ট বা সার্ভারভিত্তিক অর্ডার সংরক্ষণ নেই।

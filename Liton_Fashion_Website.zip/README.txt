LITON FASHION — starter storefront

HOW TO PUBLISH FREE WITH GITHUB PAGES
1. Sign in to https://github.com
2. Create a new public repository, for example: liton-fashion
3. Upload index.html from this folder (the file itself, not the zip).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. After deployment, your site will be available at:
   https://YOUR-USERNAME.github.io/liton-fashion/

IMPORTANT BEFORE TAKING ORDERS
Open index.html and find:
const phone="8801XXXXXXXXX";
Replace the placeholder with your WhatsApp number including Bangladesh country code 880, without + or spaces. Example format: 88017XXXXXXXX.

This is a front-end starter site. Cart and search work in the browser. Checkout prepares an order message for WhatsApp. It does not process online payments or store orders on a server. Replace sample product names/prices/images with your real inventory before publishing.
